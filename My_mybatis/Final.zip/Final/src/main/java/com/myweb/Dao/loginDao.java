package com.myweb.Dao;

import com.myweb.domain.login;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface loginDao {
    int insert(login log);
    List<login> select();
    int update(login log);
    int delete(Integer user);
    List<login> select1(Integer user);
    login login(@Param("user") Integer user,@Param("password") Integer password);
}
