package com.myweb.service;

import com.github.pagehelper.PageHelper;
import com.myweb.Dao.loginDao;
import com.myweb.Dao.stuDao;
import com.myweb.domain.login;
import com.myweb.domain.stu;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

public class service {
    private loginDao loginDao;
    private stuDao stuDao;
    public void setLoginDao(com.myweb.Dao.loginDao loginDao) {
        this.loginDao = loginDao;
    }

    public void setStuDao(com.myweb.Dao.stuDao stuDao) {
        this.stuDao = stuDao;
    }
    public void login(HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException {
        Integer user,password;
        user = Integer.valueOf(req.getParameter("user"));
        password = Integer.valueOf(req.getParameter("password"));
        HttpSession session = req.getSession();
        session.setAttribute("user",user);
        session.setAttribute("password",password);
        login login = null;
        login = loginDao.login(user,password);
        if(login == null) {
            req.getRequestDispatcher("/Wrong.jsp").forward(req,resp);
        }
        if (login.getAd()!=null){
            req.getRequestDispatcher("/AdMain.jsp").forward(req,resp);
        }if (login.getTe()!=null){
            req.getRequestDispatcher("/TeMain.jsp").forward(req,resp);
        }if (login.getStu()!=null){
            req.getRequestDispatcher("/StuMain.jsp").forward(req,resp);
        }
    }
    public void register(HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException {
        Integer user,password;
        String Ad,Te,Stu;
        user= Integer.valueOf(req.getParameter("user"));
        password= Integer.valueOf(req.getParameter("password"));
        Ad=req.getParameter("Ad");
        Te = req.getParameter("Te");
        Stu = req.getParameter("Stu");
        login log = new login();
        log.setUser(user);log.setPassword(password);log.setAd(Ad);log.setTe(Te);log.setStu(Stu);
        loginDao.insert(log);
        req.getRequestDispatcher("/Right.jsp").forward(req,resp);
    }
    public void GetUser(PrintWriter out,HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException {
        int pagenum = Integer.parseInt(req.getParameter("pagenum"));
        PageHelper.startPage(pagenum,4);
        List<login> list = loginDao.select();
        req.setAttribute("list",list);
        req.getRequestDispatcher("GetUser.jsp").forward(req,resp);
      /*  out.print("<center><table class=\"table table-bordered\"><tr><td>user</td><td>password</td><td>Ad</td><td>Te</td><td>Stu</td></tr>");
        for(login x:list){
            *//*记住使用请求转发，到删除，更新就用a标签*//*
            out.print("<tr><td>"+x.getUser()+"</td><td>"+x.getPassword()+"</td><td>"+x.getAd()+"</td><td>"+x.getTe()+"</td><td>"+x.getStu()+"</td>");
            out.print("<td><a href='/myweb/deuser?user="+x.getUser()+"'>删除用户</td>");
            out.print("<td><a href='/myweb/UpdateUser.jsp'>更新用户</td></tr>");
        }
        out.print("</table></center>");*/

    }
    public void GetOne(HttpServletRequest req,HttpServletResponse resp,PrintWriter out) throws ServletException, IOException {
        HttpSession session = req.getSession();
        Integer user = (Integer) session.getAttribute("user");
        List<login> list = loginDao.select1(user);
        req.setAttribute("list",list);
        req.getRequestDispatcher("GetOne.jsp").forward(req,resp);
        /*out.print("<center><table class=\"table table-bordered\"><tr><td>user</td><td>password</td><td>Ad</td><td>Te</td><td>Stu</td></tr>");
        for(login x:list){
            out.print("<tr><td>"+x.getUser()+"</td><td>"+x.getPassword()+"</td><td>"+x.getAd()+"</td><td>"+x.getTe()+"</td><td>"+x.getStu()+"</td>");
            out.print("<td><a href='/myweb/UpdateUser.jsp'>更新用户</td></tr>");
        }
        out.print("</table></center>");*/
    }
    public void UpdateUser(HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException {
        Integer user,password;
        user= Integer.valueOf(req.getParameter("user"));
        password= Integer.valueOf(req.getParameter("password"));
        login log = new login();
        log.setUser(user);log.setPassword(password);
        loginDao.update(log);
        req.getRequestDispatcher("/UpdateSuccess.jsp").forward(req,resp);
    }
    public void Delete(HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException {
        Integer user = Integer.valueOf(req.getParameter("user"));
        loginDao.delete(user);
        req.getRequestDispatcher("/DeleteSuccess.jsp").forward(req,resp);
    }
    public void registerStu(HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException {
        Integer id,tel,mid,end;String semester,cname,ename,sclass,status;
        id= Integer.valueOf(req.getParameter("id"));tel= Integer.valueOf(req.getParameter("tel"));
        semester= req.getParameter("semester");mid= Integer.valueOf(req.getParameter("mid"));
        end= Integer.valueOf(req.getParameter("end"));cname=req.getParameter("cname");
        ename=req.getParameter("ename");sclass=req.getParameter("sclass");status=req.getParameter("status");
        stu stu = new stu();stu.setId(id);stu.setCname(cname);stu.setEname(ename);stu.setEnd(end);stu.setMid(mid);
        stu.setSclass(sclass);stu.setSemester(semester);stu.setStatus(status);stu.setTel(tel);
        stuDao.insert(stu);
        req.getRequestDispatcher("/Right.jsp").forward(req,resp);
    }
    /*public void GetStu(PrintWriter out){
        List<stu> list = stuDao.selectByAd();
        out.print("<center><table class=\"table table-bordered\"><tr><td>id</td><td>cname</td><td>ename</td><td>tel</td><td>sclass</td><td>semester</td><td>mid</td><td>end</td><td>status</td></tr>");
        for(stu x:list){
            *//*记住使用请求转发，到删除，更新就用a标签*//*
            out.print("<tr><td>"+x.getId()+"</td><td>"+x.getCname()+"</td><td>"+x.getEname()+"</td><td>"+x.getTel()+"</td><td>"+x.getSclass()+"</td><td>"+x.getSemester()+"</td><td>"+x.getMid()+"</td><td>"+x.getEnd()+"</td><td>"+x.getStatus()+"</td>");
            out.print("<td><a href='/myweb/destu?id="+x.getId()+"'>删除学生</td>");
            out.print("<td><a href='/myweb/UpdateStu.jsp'>更新学生信息</td></tr>");
        }
        out.print("</table></center>");
    }*/
    public void GetStuByTe(PrintWriter out,HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        Integer user= (Integer) session.getAttribute("user");Integer password = (Integer) session.getAttribute("password");
        login log = loginDao.login(user,password);
        Integer pagenum = Integer.valueOf(req.getParameter("pagenum"));
        PageHelper.startPage(pagenum,4);
        List<stu> list = stuDao.selectByTe(log);
        req.setAttribute("list",list);
        req.getRequestDispatcher("GetStuByTe.jsp").forward(req,resp);
        /*out.print("<center><table class=\"table table-bordered\"><tr><td>id</td><td>cname</td><td>ename</td><td>tel</td><td>sclass</td><td>semester</td><td>mid</td><td>end</td><td>status</td></tr>");
        for(stu x:list){
            *//*记住使用请求转发，到删除，更新就用a标签*//*
            out.print("<tr><td>"+x.getId()+"</td><td>"+x.getCname()+"</td><td>"+x.getEname()+"</td><td>"+x.getTel()+"</td><td>"+x.getSclass()+"</td><td>"+x.getSemester()+"</td><td>"+x.getMid()+"</td><td>"+x.getEnd()+"</td><td>"+x.getStatus()+"</td>");
            out.print("<td><a href='/myweb/destu?id="+x.getId()+"'>删除学生</td>");
            out.print("<td><a href='/myweb/UpdateStu.jsp'>更新学生</td></tr>");
        }
        out.print("</table>");
        out.print("<form action=\"getbyte\"><h4>输入页数进行查询</h4><input name=\"pagenum\" type=\"text\"><input type=\"submit\" value=\"查询\"></form>");
        out.print("</center>");
*/

    }
    public void GetStuByStu(PrintWriter out,HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        Integer user = (Integer) session.getAttribute("user");
        List<stu> list = stuDao.selectByStu(user);
        req.setAttribute("list",list);
        req.getRequestDispatcher("GetStuByStu.jsp").forward(req,resp);
       /* out.print("<center><table class=\"table table-bordered\"><tr><td>id</td><td>cname</td><td>ename</td><td>tel</td><td>sclass</td><td>semester</td><td>mid</td><td>end</td><td>status</td></tr>");
        for(stu x:list){
            *//*记住使用请求转发，到删除，更新就用a标签*//*
            out.print("<tr><td>"+x.getId()+"</td><td>"+x.getCname()+"</td><td>"+x.getEname()+"</td><td>"+x.getTel()+"</td><td>"+x.getSclass()+"</td><td>"+x.getSemester()+"</td><td>"+x.getMid()+"</td><td>"+x.getEnd()+"</td><td>"+x.getStatus()+"</td>");
            out.print("<td><a href='/myweb/UpdateStuByStu.jsp'>更新用户</td></tr>");
        }
        out.print("</table></center>");*/
    }
    public void UpdateStu(HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException {
        Integer id,tel,mid,end;String semester,cname,ename,sclass,status;
        id= Integer.valueOf(req.getParameter("id"));tel= Integer.valueOf(req.getParameter("tel"));
        semester= req.getParameter("semester");mid= Integer.valueOf(req.getParameter("mid"));
        end= Integer.valueOf(req.getParameter("end"));cname=req.getParameter("cname");
        ename=req.getParameter("ename");sclass=req.getParameter("sclass");status=req.getParameter("status");
        stu stu = new stu();stu.setId(id);stu.setCname(cname);stu.setEname(ename);stu.setEnd(end);stu.setMid(mid);
        stu.setSclass(sclass);stu.setSemester(semester);stu.setStatus(status);stu.setTel(tel);
        stuDao.update(stu);
        req.getRequestDispatcher("/UpdateSuccess.jsp").forward(req,resp);
    }
    public void UpdateByStu(HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException {
        Integer id,tel;String cname,ename;
        id= Integer.valueOf(req.getParameter("id"));tel= Integer.valueOf(req.getParameter("tel"));
        cname=req.getParameter("cname");ename=req.getParameter("ename");
        stu stu = new stu();stu.setId(id);stu.setCname(cname);stu.setEname(ename);stu.setTel(tel);
        stuDao.updateByStu(stu);
        req.getRequestDispatcher("/UpdateSuccess.jsp").forward(req,resp);
    }
    public void DeleteStu(HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException {
        Integer id = Integer.valueOf(req.getParameter("id"));
        stuDao.delete(id);
        req.getRequestDispatcher("/DeleteSuccess.jsp").forward(req,resp);
    }
    public void GetStu(PrintWriter out,HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException {
        int pageNum = Integer.parseInt(req.getParameter("pagenum"));
        out.print("当前是第"+pageNum+"页(共5页)");
        PageHelper.startPage(pageNum,4);
        List<stu> list = stuDao.selectByAd();
        req.setAttribute("list",list);
        req.getRequestDispatcher("GetStu.jsp").forward(req,resp);
       /* out.print("<center><table class=\"table table-bordered\"><tr><td>id</td><td>cname</td><td>ename</td><td>tel</td><td>sclass</td><td>semester</td><td>mid</td><td>end</td><td>status</td></tr>");
        for(stu x:list){
            *//*记住使用请求转发，到删除，更新就用a标签*//*
            out.print("<tr><td>"+x.getId()+"</td><td>"+x.getCname()+"</td><td>"+x.getEname()+"</td><td>"+x.getTel()+"</td><td>"+x.getSclass()+"</td><td>"+x.getSemester()+"</td><td>"+x.getMid()+"</td><td>"+x.getEnd()+"</td><td>"+x.getStatus()+"</td>");
            out.print("<td><a href='/myweb/destu?id="+x.getId()+"'>删除学生</td>");
            out.print("<td><a href='/myweb/UpdateStu.jsp'>更新学生信息</td></tr>");
        }
        out.print("</table>");*/
        /*out.print("<form action=\"gets\"><h4>输入页数进行查询</h4><input name=\"pagenum\" type=\"text\"><input type=\"submit\" value=\"查询\"></form>");
        out.print("<form action=\"getsbyc\"><h4>输入班级进行查询</h4><input name=\"sclass\" type=\"text\"><input type=\"hidden\" name=\"pagenum\" value=\"1\"><input type=\"submit\" value=\"查询\"></form>");
        out.print("<form action=\"getbycn\"><h4>输入中文名字进行查询</h4><input name=\"cname\" type=\"text\"><input type=\"submit\" value=\"查询\"></form>");
        out.print("<a href=\"gets?pagenum=1\">1</a>");
        out.print("<a href=\"gets?pagenum=2\">2</a>");
        out.print("<a href=\"gets?pagenum=3\">3</a>");
        out.print("<a href=\"gets?pagenum=4\">4</a>");
        out.print("<a href=\"gets?pagenum=5\">5</a>");
        out.print("</center>");*/
    }
    public void GetStuByClass(PrintWriter out,HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException {
        int pageNum = Integer.parseInt(req.getParameter("pagenum"));
        String sclass = req.getParameter("sclass");
        out.print("当前是第"+pageNum+"页(共5页)");
        PageHelper.startPage(pageNum,4);
        List<stu> list = stuDao.selectByClass(sclass);
        req.setAttribute("list",list);
        req.getRequestDispatcher("GetStuByClass.jsp").forward(req,resp);
      /*  out.print("<center><table class=\"table table-bordered\"><tr><td>id</td><td>cname</td><td>ename</td><td>tel</td><td>sclass</td><td>semester</td><td>mid</td><td>end</td><td>status</td></tr>");
        for(stu x:list){
            *//*记住使用请求转发，到删除，更新就用a标签*//*
            out.print("<tr><td>"+x.getId()+"</td><td>"+x.getCname()+"</td><td>"+x.getEname()+"</td><td>"+x.getTel()+"</td><td>"+x.getSclass()+"</td><td>"+x.getSemester()+"</td><td>"+x.getMid()+"</td><td>"+x.getEnd()+"</td><td>"+x.getStatus()+"</td>");
            out.print("<td><a href='/myweb/destu?id="+x.getId()+"'>删除学生</td>");
            out.print("<td><a href='/myweb/UpdateStu.jsp'>更新学生信息</td></tr>");
        }
        out.print("</table>");
        out.print("<form action=\"getsbyc\"><h4>输入页数进行查询</h4><input name=\"pagenum\" type=\"text\"><input type=\"hidden\" name=\"sclass\" value=\""+sclass+"\"><input type=\"submit\" value=\"查询\"></form>");
        out.print("<form action=\"getbycn\"><h4>输入中文名字进行查询</h4><input name=\"cname\" type=\"text\"><input type=\"submit\" value=\"查询\"></form>");
        out.print("</center>");*/
    }
    public void GetStuByCname(PrintWriter out,HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException {

        String cname= req.getParameter("cname");
        List<stu> list = stuDao.selectByCname(cname);
        req.setAttribute("list",list);
        req.getRequestDispatcher("GetStuByCname.jsp").forward(req,resp);
       /* out.print("<center><table class=\"table table-bordered\"><tr><td>id</td><td>cname</td><td>ename</td><td>tel</td><td>sclass</td><td>semester</td><td>mid</td><td>end</td><td>status</td></tr>");
        for(stu x:list){
            *//*记住使用请求转发，到删除，更新就用a标签*//*
            out.print("<tr><td>"+x.getId()+"</td><td>"+x.getCname()+"</td><td>"+x.getEname()+"</td><td>"+x.getTel()+"</td><td>"+x.getSclass()+"</td><td>"+x.getSemester()+"</td><td>"+x.getMid()+"</td><td>"+x.getEnd()+"</td><td>"+x.getStatus()+"</td>");
            out.print("<td><a href='/myweb/UpdateStuByStu.jsp'>更新用户</td></tr>");
        }
        out.print("</table></center>");*/
    }


}
