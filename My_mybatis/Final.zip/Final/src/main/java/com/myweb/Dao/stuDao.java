package com.myweb.Dao;

import com.myweb.domain.login;
import com.myweb.domain.stu;

import java.util.List;

public interface stuDao {
    int insert(stu s);
    List<stu> selectByAd();
    List<stu> selectByTe(login log);
    List<stu> selectByStu(Integer user);
    List<stu> selectByClass(String sclass);
    List<stu> selectByCname(String cname);
    int update(stu s);
    int updateByStu(stu s);
    int delete(Integer id);
}
