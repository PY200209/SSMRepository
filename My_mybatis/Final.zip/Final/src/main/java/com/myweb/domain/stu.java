package com.myweb.domain;

public class stu {
    private Integer id;   private String cname;  private  String ename ;
    private Integer tel ;private String sclass;
    private String semester;private Integer mid,end ;
    private String status;
    private login l;

    public void setId(Integer id) {
        this.id = id;
    }

    public void setCname(String cname) {
        this.cname = cname;
    }

    public void setEname(String ename) {
        this.ename = ename;
    }

    public void setTel(Integer tel) {
        this.tel = tel;
    }

    public void setSclass(String sclass) {
        this.sclass = sclass;
    }

    public void setMid(Integer mid) {
        this.mid = mid;
    }

    public void setEnd(Integer end) {
        this.end = end;
    }

    public void setSemester(String semester) {
        this.semester = semester;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getId() {
        return id;
    }

    public String getCname() {
        return cname;
    }

    public String getEname() {
        return ename;
    }

    public String getSclass() {
        return sclass;
    }

    public Integer getTel() {
        return tel;
    }

    public String getSemester() {
        return semester;
    }

    public Integer getMid() {
        return mid;
    }

    public Integer getEnd() {
        return end;
    }

    public String getStatus() {
        return status;
    }
}
