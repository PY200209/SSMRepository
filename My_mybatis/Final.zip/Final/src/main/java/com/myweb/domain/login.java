package com.myweb.domain;

public class login {
    private Integer user;
    private Integer password;
    private String Ad;
    private String Te;
    private String Stu;

    public void setStu(String stu) {
        Stu = stu;
    }

    public void setTe(String te) {
        Te = te;
    }

    public void setAd(String ad) {
        Ad = ad;
    }

    public void setPassword(Integer password) {
        this.password = password;
    }

    public void setUser(Integer user) {
        this.user = user;
    }

    public Integer getUser() {
        return user;
    }

    public Integer getPassword() {
        return password;
    }

    public String getAd() {
        return Ad;
    }

    public String getTe() {
        return Te;
    }

    public String getStu() {
        return Stu;
    }
}
